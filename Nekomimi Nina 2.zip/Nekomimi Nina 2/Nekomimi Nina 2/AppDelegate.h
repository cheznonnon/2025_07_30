//
//  AppDelegate.h
//  Nekomimi Nina 2
//
//  Created by のんのん２ on 2023/12/17.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

