//
//  AppDelegate.m
//  Nonnon Poker
//
//  Created by のんのん２ on 2024/12/18.
//


#import "AppDelegate.h"




#include "n_game.c"




@interface AppDelegate ()

@property (strong) IBOutlet NSWindow *window;

@property (weak) IBOutlet NonnonGame *n_game;

@property (weak) IBOutlet NSMenuItem *n_menu_bet;
@property (weak) IBOutlet NSMenuItem *n_menu_endless;

@end




@implementation AppDelegate {

	BOOL endless_onoff;
	int  coin;

}




- (void) NonnonPokerSettings : (BOOL) is_read
{

	NSString *nsstr;

	if ( is_read )
	{
#ifdef N_POKER_NO_GAMBLE
		endless_onoff = TRUE;

		[_n_menu_bet     setState:NSControlStateValueOff];
		[_n_menu_endless setState:NSControlStateValueOn ];

		[_n_menu_bet     setHidden:YES];
		[_n_menu_endless setHidden:YES];
#else
		nsstr = n_mac_settings_read( @"endless_mode" );
		if ( nsstr.length == 0 ) { nsstr = [NSString stringWithFormat:@"0"]; }

		endless_onoff = [nsstr intValue];
		if ( endless_onoff )
		{
			[_n_menu_bet     setState:NSControlStateValueOff];
			[_n_menu_endless setState:NSControlStateValueOn ];
		} else {
			[_n_menu_bet     setState:NSControlStateValueOn ];
			[_n_menu_endless setState:NSControlStateValueOff];
		}
#endif

#ifdef DEBUG
		nsstr = @"500";
#else // #ifndef DEBUG
		nsstr = n_mac_settings_read( @"coin" );
		if ( nsstr.length == 0 ) { nsstr = [NSString stringWithFormat:@"500"]; }
#endif // #ifndef DEBUG

#ifdef N_POKER_RESET_COIN
		nsstr = [NSString stringWithFormat:@"500"];
#endif
		coin = [nsstr intValue];

	} else {

		nsstr = [NSString stringWithFormat:@"%d", endless_onoff];
		n_mac_settings_write( @"endless_mode", nsstr );

#ifdef N_POKER_WRITE_COIN

#ifndef DEBUG
		coin = [_n_game n_mac_game_coin_get];
		if ( coin == 0 ) { coin = N_POKER_COIN_DEFAULT; }
		nsstr = [NSString stringWithFormat:@"%d", coin];
		n_mac_settings_write( @"coin", nsstr );
#endif // #ifndef DEBUG

#endif // #ifdef N_POKER_WRITE_COIN

	}

}




- (void)awakeFromNib
{
//NSLog( @"awakeFromNib" );

	[_window makeKeyWindow];


	n_mac_image_window = _window;
	n_gdi_scale_factor = n_mac_image_window.backingScaleFactor;


#ifdef N_POKER_NO_GAMBLE
	_window.title = @"Nonnon Poker (AppStore Edition)";
#endif

	[self NonnonPokerSettings:YES];
	[_n_game n_mac_game_init:endless_onoff coin:coin];

	[_n_game n_mac_game_canvas_resize:_window width:-1 height:-1];

	[[NSNotificationCenter defaultCenter]
	      addObserver: self
		 selector: @selector( windowWillClose: )
		     name: NSWindowWillCloseNotification
		   object: nil
	];

	// [!] : accent color
	[[NSDistributedNotificationCenter defaultCenter]
		addObserver: self
		   selector: @selector( accentColorChanged: )
		       name: @"AppleColorPreferencesChangedNotification"
		     object: nil
	];

	// [!] : dark mode
	[[NSDistributedNotificationCenter defaultCenter]
		addObserver: self
		   selector: @selector( darkModeChanged: )
		       name: @"AppleInterfaceThemeChangedNotification"
		     object: nil
	];

}




- (void) windowWillClose:(NSNotification *)notification
{
//NSLog( @"closed" );

	[self NonnonPokerSettings:NO];

	NSWindow *window = notification.object;
	if ( window == self.window )
	{
		[NSApp terminate:self];
	}
}

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application

	//[_n_game n_game_start];

}




- (void)applicationWillTerminate:(NSNotification *)aNotification {
	// Insert code here to tear down your application
}


- (BOOL)applicationSupportsSecureRestorableState:(NSApplication *)app {
	return YES;
}




- (void) accentColorChanged:(NSNotification *)notification
{
//NSLog( @"accentColorChanged" );

	// [x] : Sonoma : buggy : old value is set

	//[_n_game n_accentColorChanged];

	n_mac_timer_init_once( self, @selector( n_timer_method_color ), 200 );

}

- (void) n_timer_method_color
{
//NSLog( @"n_timer_method_color" );

	[_n_game n_accentColorChanged];

}

- (void) darkModeChanged:(NSNotification *)notification
{
//NSLog( @"darkModeChanged" );

	[_n_game n_darkModeChanged];

}



/*
- (IBAction)n_poker_menu_mode_ensless:(id)sender {

	NSControlStateValue s = [_menu_mode state];
	if ( s == NSControlStateValueOff )
	{
		[_menu_mode setState:NSControlStateValueOn];
		endless_onoff = TRUE;
	} else {
		[_menu_mode setState:NSControlStateValueOff];
		endless_onoff = FALSE;
	}

	[_n_game n_mac_game_mode:endless_onoff];

}
*/
- (IBAction)n_poker_menu_mode_bet:(id)sender {

	NSControlStateValue s = [_n_menu_bet state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_bet     setState:NSControlStateValueOn ];
		[_n_menu_endless setState:NSControlStateValueOff];

		endless_onoff = FALSE;
		[_n_game n_mac_game_mode:endless_onoff];
	}

}

- (IBAction)n_poker_menu_mode_endless:(id)sender {

	NSControlStateValue s = [_n_menu_endless state];
	if ( s == NSControlStateValueOff )
	{
		[_n_menu_bet     setState:NSControlStateValueOff];
		[_n_menu_endless setState:NSControlStateValueOn ];

		endless_onoff = TRUE;
		[_n_game n_mac_game_mode:endless_onoff];
	}

}




- (IBAction)n_poker_menu_readme:(id)sender {
//NSLog( @"n_poker_menu_readme" );

	NSString *helpFilePath = [[NSBundle mainBundle] pathForResource:@"nonnon_poker" ofType:@"html"];
	NSURL    *helpFileURL  = [NSURL fileURLWithPath:helpFilePath];

	[[NSWorkspace sharedWorkspace] openURL:helpFileURL];

}


@end
